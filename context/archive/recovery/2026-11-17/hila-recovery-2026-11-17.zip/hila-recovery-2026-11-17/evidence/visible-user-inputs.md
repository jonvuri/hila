# Visible user inputs — evidence excerpts

These are verbatim selections from user messages available in the active context. Each U identifier denotes a message or clearly labeled portion of one. They are not a full transcript. Ordering follows the exploration, not an inferred timestamp. Older assistant responses are not reproduced where only a summary remains.

## Task atoms, ownership, queues, lifecycle, SRS

### U01 — atomic range versus fragment

> I only want to look at atomic range vs a fragment. Atomic range would be created after typing a tag like `#task`, and it would pull in surrounding context dynamically based on heuristics. Inevitably the heuristics would be wrong sometimes, but we could probably make them good enough to get the user's intended contextual phrases on the same line or a line directly above/below, with the most common failure being getting extra unrelated prose too. Fragment would be an explicit user built span around the text, similar to a link. It would have the advantage of perfect context (user chooses what to wrap), but at the cost of entry being a bit less intuitive and quick.

### U02 — shared explicit label instead of prose fragment

> If a #task is inserted with no label, then it can just be an atomic range taking its label from the surrounding context with heuristics (some of which can try to enforce that two tasks don't get exactly the same context, if possible). After insertion, they can optionally be given a label, which stays attached to the atomic range with a wrapped border - but this is actually the label on the task row, not a part of the surrounding content. This allows for user-controlled context while retaining atomic editing, deleting, and clipboard workflows.

### U03 — preferred occurrence and context disambiguation

> let's assume a stable preferred occurrence for now. It does not need to be recorded separately, it should just be a simple deterministic property of the occurrences, like their inherent query ordering. Agreed that heuristic disambiguation should never distort prose. I just meant that if two tasks are directly adjacent and have prose before and after them, the heuristics should make a best effort to account for that and give them the context that is in closest proximity but not already 'claimed' by another task (closest wins).

### U04 — inline co-ownership gestures

> - copy-then-delete-original: Any remaining owners should continue to own - as long as one owner still has claim, the owned item survives.
> - cut/paste: owned item should be deleted normally upon cut and enter the clipboard buffer. Once pasted in a new location, it should then be restored with its same identity and content (but owned by the new location). if abandoned (that is, if something else enters the clipboard buffer evicting it) it simply stays deleted.
> - repeated paste of either copy or cut: same item, multiple owners
> - undo: same results as if the item is deleted

### U05 — deleted/recoverable row edits

> Agreed that deletion should be recoverable and concurrent field edits should apply while a row is in cut-buffered / recoverable state.

### U06 — queues and display context

> - Yes, I would expect queues to act like a view in general and naturally deduplicate rows.
> - Agreed that the usual matching occurrence's context should be shown for a task everywhere, even if that occurrence is not the occurrence that matched the queue's query. If the user wants to, they can always give the task an explicit label to resolve any confusion.
> - This is more a matter for the query spec and builder, and how it represents AND / OR conditions and their nesting / precedence. I would expect any reasonable combination that could be made in SQL to be constructible.

### U07 — existing task references (excerpt from a subsequently revised transfer discussion)

> A related gesture might be using a `@` ref sigil to link to a task row in a non-owning way. That would be the gesture I would expect to most naturally apply to 'refer to an existing task' in prose - in other words, I would intuitively expect that action to *not* apply lifecycle ownership.

### U08 — drop task-row transfer gestures

> I agree, let's drop the transfer gestures. I'm a little confused what the issue is with standalone lifetime, though. Is that not just simple, atomic lifetime of a single matrix row? It has membership lifetime with the matrix (i.e. it gets deleted if the matrix does), and potentially, ownership lifetime with any other kinds of owning edges (I don't know if we've established that all nodes must have some kind of owning, positional edge or if we've left that open for consideration in the current exploration).

### U09 — clear inline atoms

> Never mind about tombstones; let's keep it simple to start with and just clear inline atoms upon task or matrix deletion.

### U10 — import receipts

> The import receipt case seems to me like it should act like a simple reference to the imported note, not have any ownership traveling in either direction. While the imported note survives, it is useful to have a link to it, but if the note is deleted, the only thing that matters to retain is the import receipt and its reference to the import source.

### U11 — simplicity of conflict resolution

> Would we be signing up for eventually falling into rebuilding something like CRDTs? If that would be the case I might prefer to compromise the experience slightly for the sake of simplicity, preferring conflicting updates to just clobber each other at an object level with last-write-wins.

### U12 — retained history and guarded undo

> We can probably afford to keep a fairly long and complete change history across the whole app, given the intended scope is personal note taking. Though, we should account for it being cut off at the oldest item if we need to recover space.

> So, if we have object-level LWW, retain deleted records, treat deleting inline atoms like any other prose edit, require object-level undo to be done one change at a time going back, and don't provide inline atom deletion undo for any objects that have later edits (silently skipping them makes sense I think), that keeps everything coherent and simple enough, right?

### U13 — no ownerless recovery fallback

> For the first rule, let's follow the general "keep it simple and clobber" rule - if there were owners, but none are valid to restore, that row is simply not eligible for restoration. No alternative recovery options. This might mean a whole undo changeset is ineligible, and then we should just hide or skip it whole.
>
> Agreed with the rest of your suggested explicit rules. We could consider lifecycle and content edits to be different kinds of objects with different retention policies, and lifecycle could survive much longer (maybe even indefinitely) since it doesn't need to scale with the content.

### U14 — sequential SRS reviews and local reset scope

> Agreed with sequential reviews. Let's go with simple deletion semantics for learning reset. I don't think I would expect it to reset rows it hasn't seen locally; new reviews coming in on sync is fine.
>
> Agreed live recomputation makes sense to start with. We could use it as a test case for checking performance of bounded computation, given some worst-case (but plausible) test fixtures. For instance, the equivalent of daily use (fully reviewing all eligible cards each day) for ~10 years. If that still fits in roughly 250-500ms computation time, I'd call it good. If not, we should consider local-only caching, which should still be relatively simple.

### U15 — runtime B preference

> I have a slight preference for B, since ownership is more of a feature-level concern than a generic change-tracking one or native SQL; it seems like we have established that at least one shared feature runtime earns its keep. But let's see what this exercise shows.

### U16 — unknown occurrence restoration acceptance

> In the described unknown-occurrence case, if a restore following a deletion restores the same row identity for the deleted object, then we could effectively cancel out that deletion and resolve things as if it never happened, right? With the same identity and IDs, state would converge correctly without much work. Am I misunderstanding some part of the edge case, or oversimplifying?

Later acceptance:

> Great. Agreed with the qualification and resulting rule, and mirroring that reset policy is a nice bonus; tells me we're on the right track for coherency.

## Shared records and outline behavior

### U17 — interchangeable representations

> outlining, notes, and tables should all be represented in interchangeable formats, so that they can all be treated with similar SQL operations, and share views and operations in general (wherever and however that makes sense). So it should be possible to view a certain set of notes in Obsidian form with flat browsable note titles and content preview, and a full-pane content view to the right; and the same set of notes in Workflowy form with outline tree relationships shown, titles serving as the main bullet content, and longer note content (if any) shown as expandable editable smaller text below bullets.

### U18 — subtree gestures, not universal lifetime ownership

> I think being able to fluently express tree operations through SQL somehow should be a product requirement (i.e. it should be easy to express "delete a subtree"), but not enforcing subtree ownership when deleting a parent through any route.

> Let's think through an alternate model where the outline is just a view over records. The main issue this raises is... discovery and managing clutter.

From an earlier message:

> I don't think we would ever render outline items as a tree without having a single root as the focus (though with paging that root might not currently be in the results or visible).

### U19 — merge safeguards

> the natural merge destination will always be the upper one (that is being "backspaced into"). We can just prevent the operation whenever it would result in losing more data than the label, or involve anything else that would be destructive or need user input to resolve.

### U20 — lower-half split identity

> I just tested workflowy's behavior. It never allows the usual backspace-from-sibling merge into a mirror. It does allow enter to split in the middle, but with surprising behavior - it maintains the lower half as the mirror, and changes other mirror occurrences to the lower-half text, leaving the upper half as a normal bullet above the starting point.

Subsequent reversal of the initial upper-half preference:

> The practical advantages you mention make sense. Especially that children appear below the item; that alone makes lower half taking original identity seem more expected. I take back my original assumption - let's go with workflowy's.

### U21 — shared children and focused outdent

> I would expect editing or deleting any child records to be reflected in any mirror, since they are in fact the same records; only the root element itself has any special behavior (the multiple mirrored root elements, that is), and the subtree rooted below it is a singleton. This is how Workflowy works.
>
> The mirror elements can be moved anywhere freely.
>
> I wouldn't expect any normal gestures within the outline view to result in Unplaced records, mirrors included.
>
> Outdenting a child record such that it exits a mirror is an interesting case. I tested Workflowy and it does exactly what you described, removing it from all mirrors and inserting it next to (below) the mirror that held focus. That feels natural to me, too.

The no-Unplaced expectation is later qualified by U29 for concurrent gestures.

### U22 — symmetric appearances and final deletion

> I tested in workflowy; deleting the second to last mirror turns the final appearance back into a normal record. This makes sense to me. If you continue to delete the last record, it is just a normal root-and-subtree deletion.

### U23 — mirrored children during subtree deletion

> I would expect deleting a subtree with mirrors in it as children would only remove the mirror appearances, not their shared children (same as if we had deleted the mirror bullets directly).

> The one tricky bit might be detecting a situation where B is mirroring A and there are no other mirrors - in this situation I would expect it to behave as if we first deleted B (turning A into a normal non-mirrored bullet), then immediately after that deleted A and its remaining subtree.

### U24 — independent parents, shared children

> What if we consider mirror bullets to still be normal bullets for the purpose of their own appearance (aside from potential visible treatment for being a mirror, and mirror gestures being available), and only start considering the mirror aspect when we start resolving its children? In other words, every appearance has its own parents; mirrors do not share parents or their canonical outline placement, only their children.

### U25 — preference against placement cycles

> I wonder if that's more than a performance concern, that allowing cycles is just an inherent footgun for relational queries that isn't worth simplifying mirror placements. We could accept different product behavior than Workflowy there - I don't think cycles actually serve any legitimate product need.

### U26 — selected brief and start of item 1

> Agreed, this seems like a good test case. Let's set this as the brief for item 2, then start on item 1.

The preceding selected case was a film-study project; exact earlier assistant wording is not available in the carried-forward summary, but the draft brief is preserved in `prior-draft-excerpts.md`.

## Placement conflict resolution and Unplaced

### U27 — reject the whole move

> Let's say we choose any reasonable deterministic rule that results in B's move winning, thus suppressing A's move. If each move is a single atomic operation, and we could consider A's move fully struck from history, as if it had never happened, then I can't imagine an inconsistent state that could exist after playing the full revised history with that one move struck, such that A would need to become unplaced.

### U28 — omit before applying resolution

> I was imagining that we would not add step 5 but instead detect this situation ahead of time when resolving the sync and then omit step 2 entirely when playing the sync resolution out. I'm not sure how much that matters though.

> Agreed that deleting P through SQL results in unplaced A. However, it seems like a non sequitur here - it would result in that regardless of the move cycle, unless we serendipitously chose B as the winning parent instead. And yes, we already accepted Unplaced consequences for SQL operations.

### U29 — accept concurrent-gesture orphaning; no gesture dependencies

> Agreed - this case makes sense, and tracking dependent gestures seems like starting to open up significant sync complexity, out of line with our clobbering / last-write-wins philosophy. We can accept unplaced in a case like this where outline gestures unluckily combine to remove a parent relationship.

The accepted example is retained in `context-snapshot.md` and decision D32.

### U30 — wall-clock priority

> As a provisional placeholder (unless we find a good reason to prefer another resolution during implementation), we can just take the most recent wall-clock competing move, as the one most likely to be the user's more memorable and current intention.

### U31 — no retry

> Agreed on not retrying rejected moves. I'm not clear on what question the second default is answering?

### U32 — Unplaced means unreachable

> Yes. Unplaced should specifically be for records that are otherwise unreachable through the outline view, not for records that ever had a broken placement.

## Film-study presentation and editing

### U33 — title/notes roles and optional body

> title and longer-notes fields are at least commonly useful and have natural presentation in both notes and outline views, and while longer-notes is not as inherent to table, it can still have a sensible and expected place in the column next to title. Longer-notes is also conceivably optional for all three - it would be awkward for the notes view, but it could still show a larger form view of the row's fields in place of the longer-notes editor. The record shape that would be particularly awkward for notes view is a matrix with a title column and _nothing_ else - but we could still make it valid by showing an empty placeholder or not expanding a focus view at all.

> I think overloading title and longer-notes for front and back makes the most sense because it makes them naturally editable in views like outline and notes without special handling.

### U34 — same-type creation and empty-row escape

> I think creating a new row of the same type when pressing from anywhere within it is a bit preferable simply because it would otherwise require a less natural outline gesture that would require mouse or memorizing an unconventional keyboard shortcut (such as a table-like 'add row' header/footer on hover).

> Perhaps there is a set of natural gestures providing both options here, like first enter copying the original row type, and a second enter with no other input converting it in place to a normal row, as a natural "oh, I didn't expect that" capture.

### U35 — heterogeneous tables

> We definitely shouldn't pretend the records are homogeneous and squeeze them all into one bounded table with no markings. I think what might make sense is an aligned multi-table view (that is, grouping each contiguous run of homogeneous records as their own table) that shows any records sharing bindings across matrixes aligned in the same vertical, with the rest laid out however.

### U36 — reject view-specific bindings; secondary fields below

> I agree, not compelling in either case. SRS reversing does not need persistent state. 'Preferred name' or 'full name' would be a likely primary representative field for a person directory, but we could still assign it the "title" semantic role regardless of name. Also agreed on consistent region below for additional fields.

### U37 — Workflowy observations and temporarily proposed spreadsheet behavior

> In Workflowy, splitting an item from the middle then pressing enter any number of times never results in exiting the current level. it has consistent behavior: first enter splits with focus entering below, second enter creates and enters a new empty item above, subsequent enters all create and enter new empty items below. All of these cases are the same whether focus was placed there manually or had just entered from a new insert. The only case treated differently is a second enter in a new empty item at the end of the level, which could only happen from enter at the end of the previous item's text.

> Agreed that ordinary defaults should not defeat this special gesture (in fact, I'm not sure about required fields in general, vs just following Sqlite behavior of everything nullable - since it would be possible via sql regardless). Agreed it should only apply in the title editor.

> I wonder if we should follow more spreadsheet-like behavior for table views, where enter just proceeds to the next row (and creates a new row below if it doesn't exist yet), without splitting any text.

The last proposal is superseded by U45.

### U38 — hybrid mixed layout

> Perhaps a cross of contiguous tables with shared alignment and expandable fields could make sense here - show common fields in a top row per item, and additional fields in a separate row below (probably with less emphasis), with a single top header marking column fields shared across all tables, and small field labels per row for additional fields (or a smaller per-table header to be even more compact).

### U39 — state-based conversion and layout A

> For Enter on terminal film: Yes, always changes to an ordinary note at the same level, as long as the film record is in its full starting / empty state. This would be expected to usually happen after a user pressed Enter once first to create the new row, but that is not a requirement. This matches Workflowy behavior where Enter on a final empty sibling outdents it (if there is a level up in the current root view), even if you clicked to focus on it from elsewhere - the gesture is not dependent on prior gestures. (Speaking of, if the new ordinary row from a film record is also the final sibling, it should also be eligible for that.)
>
> I agree with your assessment, A is definitely the better layout. Also agree with your refinements on secondary field alignment and bounded previews.

### U40 — segment boundary, not sibling-list boundary

> the important position is the end of the contiguous range of film rows. That is the positional constraint for turning a non-ordinary row into an ordinary row. It might overlap with the final sibling position for auto outdent, but isn't the same.

> No, enter at the end of one contiguous range of types inserts a new row of that type, just like if ordinary notes followed it. Adjacent contiguous rows of differing types do not act like the same table, they act like there is an "air gap" between them.

> In what situation would we have an "insert between" control at all, rather than always "insert below"? The latter seems less ambiguous and just as capable.

### U41 — split typed records into same type

> Yes, it should create another film in general - I think that feels most natural (but this is a tough case).

### U42 — rejected alternatives for inserting above

> - Press Enter a second time with an empty typed row above inserts another empty _ordinary_ row above the empty typed row.
> - Press Enter a second time with an empty typed row above converts the row above into an empty ordinary row in place.
>
> The second gesture mirrors the insert below behavior more closely but feels less natural because the row being converted does not have focus in this case - it would be action at a distance.
>
> I'm not sure if the first gesture is better in that regard though, because pressing Enter several times in a row would result in "dragging" the new empty typed row down, which acts against the visual that one is inserting new rows going down (with the oldest at the top, not the bottom).

### U43 — accept Enter, Up, Enter

> I agree with your first recommendation; it also implies that if the user does not press up arrow, typed rows continue to be created, which is fine.

The accepted recommendation was to preserve focus on the original lower row, navigate up to the new empty row, then convert it with Enter at the beginning of its typed segment. This expands conversion to both segment boundaries.

### U44 — reconsider table navigation

> Your mention of Tana having more outline-like behavior has me questioning the behavior we already settled of *not* splitting on enter in the middle of tables. Why did we do that again? It seems weird to add tables with Enter at one end of a table, but not in the middle with the same gesture.

### U45 — accept uniform title editing

> I agree. Let's switch to this model for consistent expectations and natural gestures in both modes. Anything left to settle for this trace?

The preceding assistant proposal specified split within title, insert above at start, insert below at end even between existing rows, empty boundary conversion, and field-specific behavior elsewhere.

## Matrices and saved views

### U46 — bounded preview leaning, not final acceptance

> It would be nice to support browsing and modifying matrix member rows inline in the outline, but just having a smaller preview that needs to be focused for full browsing (whether that focusing sets the root of the current view or opens a new view) would be a clear signal that the matrix itself is the appearance entry, and it would imply that member rows themselves do not have outline positions (which would make things simpler - trying to support this got hairy in the last architecture). I'm leaning towards that (bounded preview + focus required), but see if there are any compelling devil's advocate points for inline browsing before we settle.

### U47 — Unplaced for collections and last-appearance deletion

> Unplaced seems like a good default - are there any reasons we might want to consider a separate view specific to matrixes or saved views, instead?

> I'm inclined towards making deleting the last appearance of a matrix automatically delete it and its rows, because this matches deleting normal outline entries and also makes it possible to delete matrixes from the outline view more naturally. This might mean we would need a confirmation dialog since the blast radius is wider than a local subtree; or maybe easy undo is enough?

### U48 — reopen full inline rendering

> I'm returning to this after a long while. I read through the last message and I'm now currently wondering why not just full inline spread of matrix rows in the outline with matrix-related affordances inline around it as needed?

### U49 — latest explicit collection decisions

> - Yes, unplaced for currently unreachable matrixes and views, with the same rules as ordinary nodes. In general, we can treat a matrix node (as one unit, the whole table) as a node, right?
> - Yes, matrix is a discovery route to its members; that feels most natural particularly with full inline rendering.
> - Confirm deletion only if there actually are external incoming references or appearances; otherwise normal undo will suffice.

## Recovery and durability

### U50 — loss matters

> I meant the uncommitted draft, yes. What we can recover will be lower fidelity - that is substantial lost work. Is this a known issue with this codex cloud environment? This is entirely transient? What lifetime can I depend on?

### U51 — first-pass recovery request

> Fair enough. Now, let's focus on recovery, trying to be efficient about context so we can at least use everything available here in the conversation before the next compaction. If you are able to, write out or retain your entire transcript first (and any other potentially useful artifacts) to a temp dir. Then, write out a full decision log to a file that captures the immediate context and most relevant inputs for all decisions we seem to have settled here, along with what the settled decision and rationale appears to have been for each. This first pass should be straightforward and efficient. Do these steps first, then we can try to recover more detailed rationales, example scenarios, and relationships between each item.
