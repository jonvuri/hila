# Context snapshot for continuation

Reconstructed factual handoff from the active context, including the prior compaction summary. Not a transcript and not implementation authority.

## Purpose and boundaries

Explore a simpler SQL-centered relational runtime for Hila through concrete tasks, SRS, and outline/notes/table use cases. Previous canonical architecture and older revamp proposals are references, not inherited constraints. Keep provisional exploration separate from canonical Concepts/Decisions. User values intuitive gestures, low sync complexity, object-level clobbering, and concrete use cases over universal abstraction. No implementation, benchmark, migration, or canonical architecture revision has occurred in this exploration.

## Exact committed baseline and navigation

- Repository: /workspace/hila; remote https://github.com/jonvuri/hila.git.
- Intended exploration branch: docs/full-revamp.
- 97ce96b: docs: resolve relational runtime worked-trace policies; pushed after explicit user authorization.
- af1b7d3: docs: checkpoint runtime and outline exploration; pushed after a later explicit request.
- Remote still at af1b7d302f9a07a7f85b1c86fd2e448e88fd19a9, verified 2026-11-17.
- Current resumed local checkout: clean work branch at e1afdad (older main baseline); fetched exploration commit is available as FETCH_HEAD.
- Do not confuse a stale checkout with missing remote commits.
- Documentation: Relational runtime exploration.md (brief), Relational runtime worked traces.md (task/SRS), Relational runtime sketches.md (A/B and adversarial sync), Relational outline exploration.md, Relational concept review.md, NOW.md and README routes.

## Runtime sketches and adversarial trace (summary evidence)

Sketch A: ordinary feature relations plus shared transaction/sync/history helpers; feature lifecycle functions installed as needed.
Sketch B: ordinary feature data plus a small shared feature lifecycle runtime above generic SQL/change tracking; task/SRS/editor libraries cooperate through it. User favored B provisionally because ownership is a feature-level concern. Agent exercises supported a narrow shared layer, not a universal graph engine. Agent names: /root/feature_relations_sketch and /root/shared_foundation_sketch. Their raw standalone reports are not available in the current filesystem; committed sketches preserve the conclusions.

Logical candidate facts: stable identities/membership, content revisions, explicit lifecycle, retained ownership claims, action history. Inline occurrence indexing comes from winning host content. Explicit deletion differs from last-owner inactivity. Deleting a task must coordinate prose cleanup, not only lifecycle facts.

Adversarial baseline N contains A→T and B→U, each sole owner. D1 deletes T and writes host n1 removing A/retiring known A. D2 writes n2 editing prose while retaining A/B, optionally completes T. If n1 wins, D2 prose is clobbered; valid undo may restore A/T with reconciled task content. If n2 wins, live content must still exclude known retired A; U survives. Host undo with a later revision is ineligible, and without a valid T owner the whole undo may be skipped. Candidate normalization filters authored content by lifecycle/retirement rather than writing fresh cleanup versions in a sync loop. Candidate action manifests/staging for partial delivery were discussed, not proven or implemented.

Unknown X, not seen at deletion, is suppressed while T is deleted but not permanently retired simply for arriving then. After explicit same-ID restore, X may become live whether it arrived before or after restore. Known removed A remains retired unless validly restored. This mirrors reset deleting only locally seen reviews.

## Accepted concurrent outline-gesture example

This example is crucial: do not replace it with a SQL deletion example that misses the user's question.

Initial R has P and B; P has A. Device 1 moves A under B, then deletes the now-empty P through an ordinary outline gesture. That deletion's locally selected affected set is only P. Device 2 independently moves B under A. Sync picks B's move and rejects A's move in full. A therefore retains P as parent, B becomes A's child, and the recorded deletion of P still applies. A is Unplaced with B below it.

Rejected alternatives: replay the semantic delete gesture and expand it to A/B (deletes records never selected locally); reject dependent gestures too (requires dependency tracking). Accepted: original deletion targets, no dependent-gesture tracking, accept rare Unplaced after concurrent gestures. In the two-move-only case, reject A's move and obtain R→A→B, not Unplaced.

## Film-study example and layout artifact

Film study contains Cinematography and Adaptation topic notes. Arrival film is explicitly placed under both. Cinematography also has Lighting observations (ordinary note with an inline task) and What is negative fill? (card). Film fields: title, year, rating, watched date, longer notes. Role bindings map title/notes onto existing fields, with cards using front/back roles.

A generated comparison image was shown earlier. Original path: /workspace/generated_images/exec-761e4674-c518-4282-ba36-6a6831221d90.png. It is not present in the resumed workspace; no recoverable local image was found during this pass. The image may remain visible in the chat UI. Do not regenerate it and call that recovery of the original.

Image A: common Title/Notes header; type badges; per-record secondary rows with small field labels. Image B: smaller per-group secondary headers. Dataset: Arrival, Blade Runner 2049, Lighting observations, What is negative fill?, In the Mood for Love, preserving the final separated film segment. User chose A; secondary values aligned within homogeneous runs, bounded prose previews, optional expansion.

## Important corrections and superseded paths

- No task-row copy/cut/drag into prose. Earlier long transfer metaphors are discarded. Inline owning-atom copy/cut/paste remain.
- No visible task tombstones initially; clear inline atoms.
- No universal positional lifecycle ownership; subtree delete is a gesture.
- Mirrors are symmetric appearances; no lasting privileged original. Shared children and local root positions.
- Split lower half retains identity; later typed-record decisions make new upper row same matrix (the old committed phrase "ordinary sibling" needs updating).
- Placement cycles were explored permissively, then excluded as product direction.
- Latest-parent edge suppression causing avoidable Unplaced was rejected in favor of omitting the whole losing move.
- Empty typed-row conversion is state-based, not dependent on a just-created flag.
- Conversion boundary is a contiguous type/matrix segment, not necessarily the final outline sibling.
- Both segment boundaries qualify after the Enter/Up/Enter decision.
- Table title Enter originally navigated cells and avoided split; latest agreement replaces this with the same title semantics as outline.
- No neutral insert-between control needed; insertion can be anchored below a row.
- No action-at-a-distance converting an unfocused empty predecessor.
- Preview-only matrix navigation was a leaning/recommendation, not a settled requirement. Full inline browsing is reopened; exact gestures remain next.
- Assistant's confirm-every-nonempty-matrix recommendation is superseded: confirm only when external incoming references or appearances exist.

## Latest current position

Matrix as one whole-table navigation node is acceptable at the product level; exact physical node typing/schema not selected. Unplaced applies to currently unreachable matrices/views under ordinary rules. An accessible matrix is a discovery route to members. The user favored final-appearance matrix deletion deleting the matrix and member rows, consistent with ordinary outline deletion; keep it a gesture, not an automatic cascade from every missing parent.

Next product trace: full inline membership-derived rows; editing/deleting/moving across the collection boundary; which operations affect matrix membership versus independent outline placement. Preserve old settled task/SRS behavior.

## Unresolved matters to avoid accidentally settling during recovery

- Physical representation of matrices, views, placements and dependencies; matrix meta-record membership; concrete SQL helpers/runtime API.
- Deterministic move rejection algorithm, prior placement retention, causal/delivery details, history pruning, transaction visibility; wall-clock ordering is only a placeholder policy.
- Discovery scope/entry-root selection and avoiding internal review/receipt clutter. Matrix discovery routes are accepted; arbitrary query-result routes and recursive matrix rendering still need care.
- Exact full-empty/default predicate, nullable versus required user fields, safe type conversion and identity/membership handling, rich-text selections/atoms in split/merge.
- Full inline matrix boundary gestures, ordering, indent/outdent, drag/drop, selections across surfaces; query views still have limited creation capabilities.
- Exact external-reference confirmation scope/counts, snapshot timing, dependent saved-view behavior after source matrix deletion, undo details for matrix deletion.
- Query/rendering feasibility and fixtures, local caches, SRS algorithm and benchmarks, stream/Miller-column UI.

## External research retained as links and findings

- https://outliner.tana.inc/learn/features/views: official docs explicitly describe Enter at end of a leftmost-column node inserting an in-between table row. Does not establish mid-title table split behavior.
- https://outliner.tana.inc/learn/features/keyboard-shortcuts: Enter described as inserting a sibling; no precise mid-title split documentation found.
- https://outliner.tana.inc/learn/features/supertags: tag removal via tag control/context menu/command line. No documented exact two-Enter escape found.
- https://www.notion.com/help/tables and https://www.notion.com/help/keyboard-shortcuts: no conclusive exact mid-title Enter database-cell behavior found. Do not infer database behavior from ordinary text blocks or simple tables.
- https://help.openai.com/en/articles/20001545-using-codex-cloud: default VM recovery up to seven days after last turn start/resume, separate from chat retention; support can investigate missing task files, no recovery promise. October 18 to November 17 gap is consistent with expiry but logs do not prove cause.

## Recovery execution limits

User asked first for efficient preservation and decision inventory, deferring richer relationships and rationale recovery to a later pass. Do not spend this pass reopening design questions, generating new mockups, implementing code, or promoting proposals to settled decisions. Do not claim a lossless full transcript was exported. Local files/commits alone share VM retention; give an archive for download and later durable checkpointing.
