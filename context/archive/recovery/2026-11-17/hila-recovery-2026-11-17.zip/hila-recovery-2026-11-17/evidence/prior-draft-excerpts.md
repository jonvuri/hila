# Earlier uncommitted draft — verbatim recovered excerpts

Source: earlier `exec_command` output in this conversation, reading the then-staged files on `docs/full-revamp`. The files themselves are absent from the resumed workspace. Text below is copied from that output; these sections are NOT the latest decisions. In particular, suppressing only an edge and making A Unplaced in the two-move case was later rejected.

## From context/NOW.md (earlier draft, updated 2026-10-15)

```markdown
## Next action

Item 1 is active: discuss the [placement-integrity traces](explorations/Relational%20outline%20exploration.md#item-1-placement-integrity-and-discovery-initial-traces),
starting with SQL parent deletion and concurrent moves that form a cycle. Proposed deterministic
suppression preserves records and surfaces disconnected roots in Unplaced; the policy is not settled.

The user selected the [film-study brief for item 2](explorations/Relational%20concept%20review.md#item-2-brief-film-study-project):
notes, tasks, film/review records, cards, and saved views across notes/outline/table presentations.
Use it after placement integrity to test named matrix/view places, field bindings, creation defaults,
and mixed-schema children. Query/cache feasibility follows concrete query shapes.
```

## From context/explorations/Relational outline exploration.md

```markdown
## Item 1: placement integrity and discovery initial traces

**Status:** active investigation. The following are candidate outcomes, not settled sync mechanics.
Use an explicit browsing root R; graph arrows below describe ordered record placements. Root entry
representation and discovery scope remain to choose.

### Parent deleted directly through SQL

Start with R → Project → Kitchen → Lighting. Delete Project's record directly, without invoking
an outline subtree-delete gesture. Kitchen and Lighting remain live matrix rows. Kitchen's incoming
placement has a deleted endpoint and cannot serve as a live route. Show Kitchen once as an Unplaced
subtree root, with Lighting beneath it. Reattaching Kitchen under R changes placement, not record
identity or matrix membership. An independent valid route through a mirror would preserve ordinary
discoverability; disconnected-placement auditing is separate from missing-record discovery.

For an acyclic accepted placement graph, a candidate Unplaced query is: within the chosen discovery
scope, find live records unreachable from the browsing entry points; among that set, show records
with no accepted live parent also in the set. Expanding one exposes its descendants. Discovery across
matrix filters/entry-point boundaries needs care: an excluded parent must not hide an included child.
Unplaced is a query-backed surface, not a durable new parent or lifecycle owner.

### Two locally valid moves form a cycle after sync

Baseline: R → A and R → B. Device 1 moves A under B; device 2 independently moves B under A.
Each local move is valid, but their combined winning placement versions form A ↔ B. Whole-object
LWW for each placement does not decide a conflict between two different placement objects.

Candidate policy: keep a deterministic acyclic subset of merged placement candidates; suppress a
conflicting placement rather than deleting its record. Prefer newer revisions under a shared total
ordering, using stable tie-breakers. If device 2's move has higher priority, retain A → B and suppress
B → A. A and its B subtree become discoverable through Unplaced because neither retained root
placement remains. The opposite priority gives the symmetric result. Same inputs must produce the
same accepted graph regardless of arrival order.

One conceptual selector is to resolve each placement's own LWW version, then consider candidates in
stable priority order and accept an edge only if it does not close a cycle. This demonstrates a
possible deterministic result, not an efficient implementation plan. Production work must consider
incremental maintenance, transactions, and bounded cost. Rejecting whichever move arrives second is
insufficient. SQL reads used for ordinary tree operations must see the accepted graph; raw pending or
suppressed sync facts should not accidentally become the user-facing placement relation.

### Policy choices to settle

- Whether the suppressed move should leave its record Unplaced, or attempt a previous placement.
  Initial recommendation: preserve current record content and surface Unplaced; avoid replaying old
  locations and their possible new conflicts. This deliberately permits a sync-caused discontinuity.
- Whether a suppressed candidate can later become valid automatically or needs explicit reattachment;
  do not equate derived suppression with a durable deletion until this is decided.
- Handling direct SQL writes through the same structural invariant boundary, missing dependencies
  during partial sync, endpoint deletion/restoration, and visibility of the conflict result.
- Precise discovery scope and entry points. The illustrative query is not a finalized global policy.

Ordinary online gestures reject moves that would visibly create cycles. Sync normalization may still
produce Unplaced content, consistent with its role as recovery from cross-device discontinuities.
```

## From context/explorations/Relational concept review.md

```markdown
## Selected next sequence

The user accepted the sequence and selected a film-study project for item 2. Item 1 starts now;
its specific integrity/recovery outcomes remain proposals until discussed.

1. **Placement integrity and discovery — active.** Decide acyclicity, trace the two-device cycle,
   parent SQL deletion, invalid placements, and Unplaced reattachment. Outcome: a clear boundary
   between content-preserving sync repair and data deletion, plus a precise discovery query. Start
   with the [initial traces](Relational%20outline%20exploration.md#item-1-placement-integrity-and-discovery-initial-traces).
2. **Film-study project across notes, outline, and table — brief selected.** See the brief below.
3. **Query and rendering feasibility — follows concrete query shapes.** Use large shallow/deep/mirrored
   fixtures to define bounded reads and SQL subtree operations before choosing closure/scroll caches.
   Concrete performance tests follow implementation, not this documentation review.

## Item 2 brief: film-study project

**Purpose:** test seamless Obsidian/Workflowy-style notes and outlines with interchangeable tabular
presentation. Retain tasks and SRS as the main exercised features; add only a modest media-log case
so mixed fields and identities have a natural use.

The [earlier use-case list](Revamp%20architecture%20proposal.md) explicitly includes media reviews
(rating, prose, timestamp, external metadata), recipes/meal planning, and microjournaling. Media
logging was selected because it combines substantial prose and ordinary structured fields without
requiring ingredient aggregation, scheduling prompts, or another automation system.

### Scenario material

- Topic notes on cinematography, editing, and individual films, with titles and longer prose.
- Tasks to watch a film, compare scenes, and write a reflection, using established inline/standalone
  task semantics. Do not reintroduce row-to-prose transfer gestures.
- Film/review records with title, year, rating, date watched, and longer notes. Their exact schema and
  whether films/reviews share one matrix are questions if the trace exposes a need, not predetermined
  architecture. Start with one simple review per film; avoid expanding into a review-management system.
- Study cards for terminology and techniques, using existing fields, plus a saved Due cards view.
- A Films matrix and saved Films to revisit view as candidate named navigation entries.

Use manually entered film data. Metadata lookup, images, ingest, and automation are not prerequisites.
SRS retains its settled policies; this trace concerns navigation/presentation and record creation.

### Gestures and questions

1. Browse the same film records as flat titles/previews with a full-pane document, as bullets with
   expandable notes, and as table rows with rating/date fields. Bind views to the same records.
2. Organize topics with ordinary notes and film records; mirror a film under two topics. Explain
   shared edits and local placement without requiring duplicate record content.
3. Press Enter next to a film record and inside a mixed topic. Determine whether the new row is a
   film or ordinary note, the creation defaults, and how required fields/missing label roles behave.
4. Switch the mixed topic to a table. Distinguish its positional children from matrix membership
   and the rows selected for the table. Test whether any graph-level child restriction is necessary.
5. Open an empty Films matrix and an empty Due cards/Films to revisit view. Name, find, reference,
   and return to those objects even without results. Determine which identities need placement.
6. Remove a navigation appearance, then explicitly delete a collection or saved view. Distinguish
   those operations and their effects on records and other appearances.

**Expected output:** a concrete presentation/creation contract, field-binding needs, matrix/view
identity requirements, and evidence for or against mixed-schema child restrictions. No implementation,
canonical architecture revision, or promotion of all old node types is implied.

The task/SRS performance fixtures remain future verification work. External plugins, implementation
migration, and canonical revisions remain deferred.
```

## Earlier staging evidence

The carried-forward session summary reported five staged files, approximately 127 insertions and 25 deletions:

- context/NOW.md
- context/README.md
- context/explorations/Relational concept review.md
- context/explorations/Relational outline exploration.md
- context/explorations/Relational runtime exploration.md

Prettier, `git diff --cached --check`, and `npm run check:concepts` were reported passing at that time (86 entries, 56 documentation links). These are historical verification results, not validation of this recovery package. Other portions of those five files have not been reproduced verbatim in this excerpt file.
